<?php 
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends controller{

	public function index(){
		echo "Dashboard Index Method";
	}

	public function params($first, $second){
		echo "<b>First Name value is: ".$first."</b>";
		//echo "<br><br>second value is: ".$second;
		exit();
		$data = array('first_name' => $first, 'last_name' => $second);
		
			// First Method to call View
		//return view('params',$data);

			// Second Method to call view
		return view('params')->with(array('first_name' => $first, 'last_name' => $second, 'testdata' => $data));

	}

	public function savedata(){
		echo "Save Data Function called.";
	}

	public function formsubmit(Request $request){
		
		$this->validate($request, [
			'name' => 'required|max:255',
			'email' => 'required',
		]);
				
		$name = $email = $comments = '';
		
		if ($request->has('name')) {
			$name = $request->input('name');
		}
		if ($request->has('email')) {
			$email = $request->input('email');
		}
		if ($request->has('message')) {
			$comments = $request->input('message');
		}
		
		//$result = DB::insert("INSERT INTO users(name,email,comments) VALUES('$name','$email','$comments')");
		//$result = DB::update("UPDATE users set name = 'Test user' WHERE id = 1");
		//echo "<br><br>update user result is: ".$result;
		//$result = DB::delete('DELETE from users where id=1');
		
		/*$result = DB::select('SELECT * FROM users');
		if($result){
			foreach($result as $res){
				echo "<br>name is: ".$res->name;
				echo "<br>email is: ".$res->email;
				echo "<br>comments are: ".$res->comments;
			}
		}*/
		
		//return view('dashboard_form');
	}
	public function showform(){
		return view('contact.test_form');
	}
}
?>