<?php
Route::get('/', function () {
    return view('welcome');
});

Route::get('dashboard', function(){
	echo "This is Dashboard function";
	echo '<form action="dashboard-view" method="post">
		  	<input type="text" name="username" />
		  	<input type="password" name="password" />
		  	<input type="submit" name="submitform" value="Login" />
		  </form>';
});

Route::get('dashboard-view', 'DashboardController@index');

Route::get('dashboard-params/{first}/{second?}', 'DashboardController@params');

Route::any('dashboard-anymethod', function(){
	echo "No need for Type of Requests, like Get, Post, Put, Patch, Delete";
	echo "<br>This will works for every request.";
});

Route::post('dashboard-view','DashboardController@savedata');

Route::get('dynamic-view', function(){
	return view('child');
});

Route::get('dashboard-form', 'DashboardController@formsubmit');