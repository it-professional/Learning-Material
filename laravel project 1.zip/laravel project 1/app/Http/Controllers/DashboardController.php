<?php 
namespace App\Http\Controllers;

class DashboardController extends controller{

	public function index(){
		echo "Dashboard Index Method";
	}

	public function params($first, $second=''){
		$data = array('first_name' => $first, 'last_name' => $second);
		
			// First Method to call View
		//return view('params',$data);

			// Second Method to call view
		return view('params')->with(array('first_name' => $first, 'last_name' => $second, 'testdata' => $data));

	}

	public function savedata(){
		echo "Save Data Function called.";
	}

	public function formsubmit(){
		return view('dashboard_form');
	}
}
?>