<!DOCTYPE html>
<html>
    <head>
        <title>Laravel View</title>

        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">

        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
                font-family: 'Lato';
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 96px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="content">
                First Name is: {{$first_name}}
                <br>
                @if($last_name)
                <br>
                Last Name is: {{$last_name}}
                @endif

                @if(isset($testdata) && is_array($testdata))
                    @foreach($testdata as $key => $data)
                        {{$key}}: {{$data}} <br>
                    @endforeach
                @endif                
            </div>
        </div>
    </body>
</html>