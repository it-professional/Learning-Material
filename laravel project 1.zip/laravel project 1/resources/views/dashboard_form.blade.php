{{ $dat = 'here in dashboard form file' }}
{{ $dat }}

{!! Form::open(['action' => 'DashboardController@savedata']) !!}

{!! Form::text('field_one_name') !!}
{!! Form::submit('Go') !!}

{!! Form::close() !!}