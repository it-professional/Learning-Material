@extends('main')

@section('content')
    <p> This is child template </p>
@endsection