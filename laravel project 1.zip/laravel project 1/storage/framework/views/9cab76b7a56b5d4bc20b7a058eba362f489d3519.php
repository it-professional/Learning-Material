<!DOCTYPE html>
<html>
    <head>
        <title>Laravel View</title>

        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">

        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
                font-family: 'Lato';
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 96px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="content">
                First Name is: <?php echo e($first_name); ?>

                <br>
                <?php if($last_name): ?>
                <br>
                Last Name is: <?php echo e($last_name); ?>

                <?php endif; ?>

                <?php if(isset($testdata) && is_array($testdata)): ?>
                    <?php foreach($testdata as $key => $data): ?>
                        <?php echo e($key); ?>: <?php echo e($data); ?> <br>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php //echo "First Name is: ".$first_name;
                      //echo "<br>Last Name is: ".$last_name; ?>
            </div>
        </div>
    </body>
</html>