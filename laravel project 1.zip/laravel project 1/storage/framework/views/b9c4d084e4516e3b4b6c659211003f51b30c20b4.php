<?php echo e($dat = 'here in dashboard form file'); ?>

<?php echo e($dat); ?>


<?php echo Form::open(['action' => 'DashboardController@savedata']); ?>


<?php echo Form::text('field_one_name'); ?>

<?php echo Form::submit('Go'); ?>


<?php echo Form::close(); ?>