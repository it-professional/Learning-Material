<?php


echo "hello ";
foreach ($variable as $key => $value) {
	echo "value of variable is: ".$value;
	
}

?>