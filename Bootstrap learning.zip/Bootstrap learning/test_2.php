<div class="container">
    <h1 class="heading">Stay Connected</h1>
    <div class="row">
        <div class="col-xs-12">
           <form class="contact-form" action="" name="contact-form" method="post">
               <div class="row" id="contact">
                <div style="display:none;" class="form-control" id="contacterror">Please enter your name and email address.</div>
                <div style="display:none;" class="form-control" id="contactsuccess">Thanks for contacting us!</div>
                <div class="col-sm-4">
                    <div class="form-group"><input type="text" class="form-control input-lg" placeholder="Name*" name="name" id="name"></div>
                    <div class="form-group"><input type="text" class="form-control input-lg" placeholder="Email*" name="email" id="email"></div>
                </div>
                <div class="col-sm-8">
                    <textarea placeholder="Message" cols="" rows="6" class="form-control input-lg" name="comments" id="comments"></textarea>
                </div>
            </div>
            <br>
            <div class="text-center"><input type="submit" class="btn btn-orange" value="Submit" id="submit_button" name="submit_button"></div>
        </form>
    </div>
</div>

</div>