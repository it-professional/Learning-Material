<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <base href="http://www.primecomms.com/" />
  	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
    
  	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
  	<meta name="description" content="Prime Communications proudly serves as one of the largest Authorized Retailers of AT&amp;T products and services." />
    <title>Prime Communications</title>
  	<link href="images/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
    <link rel="stylesheet" href="css/template.css" type="text/css" />
	<link rel="stylesheet" href="css/font.css" type="text/css" />
	<script src="js/template.js" type="text/javascript"></script>
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800' rel='stylesheet' type='text/css'>

    	<script type="text/javascript">
			jQuery(document).ready(function($) {
				var stickyNavTop = $('.header').offset().top;
				var stickyNav = function(){
					var scrollTop = $(window).scrollTop(); 
					if (scrollTop > stickyNavTop) { 
						if(!$('.header').hasClass('sticky')){
						$('.header').addClass('sticky');
						 $('.banner').addClass('banner-sticky');
						}
					} else {
						$('.header').removeClass('sticky');
						$('.banner').removeClass('banner-sticky'); 
					}
				};
				stickyNav();
				
				$(window).scroll(function() {
					stickyNav();
				});
			});
		</script>
</head>



<body class="site com_content view-featured no-layout no-task">
	<!-- Body -->
	<div class="body">
			<!-- Header -->
			<header class="header" role="banner">
            <div class="container-fluid">
            	<div class="row">
				<div class="row-fluid">
					<div class="logo span3"><a class="brand" href="/"><img src="images/logo.png" alt="logo" /></a></div>
					<div class="header-right span9">
			<!--[if lte IE 7]>
			<link href="/modules/mod_maximenuck/themes/css3megamenu/css/ie7.css" rel="stylesheet" type="text/css" />
			<![endif]--><!-- debut Maximenu CK, par cedric keiflin -->
	<div class="maximenuckh ltr" id="maximenuck87" style="z-index:10;">
        <div class="maxiroundedleft"></div>
        <div class="maxiroundedcenter">
            <ul class=" maximenuck">
												<li data-level="1" class="maximenuck item101 current active first level1 " style="z-index : 12000;" ><a class="maximenuck " href="/"><span class="titreck">Home</span></a>
		</li><li data-level="1" class="maximenuck item102 level1 " style="z-index : 11999;" ><a class="maximenuck " href="/about-us"><span class="titreck">About Us</span></a>
		</li><li data-level="1" class="maximenuck item103 level1 " style="z-index : 11998;" ><a class="maximenuck " href="/pursue-a-career"><span class="titreck">Pursue a Career</span></a>
		</li><li data-level="1" class="maximenuck item134 level1 " style="z-index : 11997;" ><a class="maximenuck " href="/life-at-prime"><span class="titreck">Life at Prime</span></a>
		</li><li data-level="1" class="maximenuck item104 last level1 " style="z-index : 11996;" ><a class="maximenuck " href="/retail-locations"><span class="titreck">Retail Locations</span></a></li>            </ul>
        </div>
        <div class="maxiroundedright"></div>
        <div style="clear:both;"></div>
    </div>
    <!-- fin maximenuCK -->


					</div>

				</div>

                </div>

                </div>

			</header>

            <!-- Header -->

		
        <div class="home-banner">

		    <div class="banner" id="banner">

            	<div class="heade-bg"></div>

             		<div class="banner-right-img"></div>

             			<div class="container">

             				<div class="row">

            					<div class="banner-inner clearfix">

											<div class="moduletable">
						

<div class="custom"  >
	<div class="welcome-text">
<h3>Welcome To</h3>
<h2>Prime Communications</h2>
</div></div>
		</div>
			<div class="moduletable">
						<style type="text/css">#banner {background-image: url("http://www.primecomms.com/images/banners/home-banner-img-4.jpg") !important; background-attachment: scroll!important; background-position:center top!important; background-repeat:no-repeat!important; background-color:transparent!important;}
width:100%;
</style>		</div>
	

               					</div>

               				</div>

               			</div>

            		</div>

		</div>

			  

        

        
<div class="content">

</div>        

              

        
            
	

	</div>

	<!-- Footer -->

	<footer class="footer" role="contentinfo">

		<div class="container">

        	<div class="row">

            	<div class="row-fluid">

            	<div class="span10 offset1 sm-offsetnone">

                	<div class="row">

                    	<div class="row">

                        	<div class="row-fluid">

                            	<div class="span3">

                                	<div class="footer-link">

												<div class="moduletable">
							<h3>Site Map</h3>
						<ul class="nav menu">
<li class="item-101 current active"><a href="/" >Home</a></li><li class="item-102"><a href="/about-us" >About Us</a></li><li class="item-103"><a href="/pursue-a-career" >Pursue a Career</a></li><li class="item-134"><a href="/life-at-prime" >Life at Prime</a></li><li class="item-104"><a href="/retail-locations" >Retail Locations</a></li></ul>
		</div>
	

                                    </div>

                                </div>

                                <div class="span6">

                                	<div class="footer-center">

                                				<div class="moduletable footer-about">
							<h3>About Us</h3>
						

<div class="custom footer-about"  >
	<ul>
<li>500+ Stores</li>
<li>2,000+ Retail Sales Associates</li>
<li>16 Years of Growth</li>
</ul></div>
		</div>
			<div class="moduletable footer-social">
						

<div class="custom footer-social"  >
	<ul>
<li class="facebook"><a href="https://www.facebook.com/Prime-Communications-119707061421197" target="_blank">facebook</a></li>
<li class="linkedin"><a href="http://www.linkedin.com/company/prime-communications_868531" target="_blank">linkedin</a></li>
<li class="twitter"><a href="https://twitter.com/PrimeComms" target="_blank">twitter</a></li>
<li class="instagram"><a href="https://www.instagram.com/PrimeComms/" target="_blank">instagram</a></li>
</ul>
<div class="copyright" style="text-align: center;">&copy; 2016 Prime Communications. All rights reserved.<br /><br /><span style="font-size: 9pt;"><a href="/privacy-policy">Privacy Policy</a>&nbsp; | &nbsp;<a href="/terms-of-use">Terms of Use</a></span></div></div>
		</div>
	

                                    </div>

                                </div>

                                <div class="span3">

                                	<div class="footer-contact">

                                				<div class="moduletable">
						

<div class="custom"  >
	<div class="footer-logo"><img src="images/footer-logo.png" alt="" /></div>
<div class="address">12550 Reed Road, Suite 100 Sugar Land, TX 77478</div>
<div class="phone-number">Tel: (281) 240-7800</div>
<div class="email-id"><a href="mailto:info@primecomms.com">Email: info@primecomms.com</a></div></div>
		</div>
	

                                    </div>

                                </div>

                            </div>    

                        </div>

                    </div>    

                </div>

                </div>

            </div>

		</div>

	</footer>

	

</body>

</html>

